package com.example.xget.activities;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telecom.Connection;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.xget.R;

import java.sql.DatabaseMetaData;

public class connexion extends AppCompatActivity {



    Button bouttons;
    EditText editTextUsername;
    EditText editTextPassword;


    TextView text;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_connexion);



        bouttons=(Button) findViewById(R.id.cnx);
        editTextUsername = findViewById(R.id.nom);
        editTextPassword = findViewById(R.id.pass);
        text= findViewById(R.id.creecompte);

        bouttons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                if (username.equals("RVZ") && password.equals("2311")) {
                    // Si les identifiants sont corrects, accéder à l'interface suivante
                    Intent intent = new Intent(connexion.this, Menu.class);
                    startActivity(intent);
                } else {
                    // Si les identifiants sont incorrects, afficher un message d'erreur
                    // (Vous pouvez également ajouter d'autres logiques de gestion des erreurs ici)
                    Toast.makeText(connexion.this, "Identifiants incorrects", Toast.LENGTH_SHORT).show();
                }

            }
        });

        text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent= new Intent(connexion.this, creercompte.class);
                startActivity(intent);


            }
        });
    }
}