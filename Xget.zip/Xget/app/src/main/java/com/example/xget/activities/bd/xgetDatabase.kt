package com.example.xget.activities.bd;

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.math.MathContext

//cree un constructeur
class xgetDatabase(mContext: Context): SQLiteOpenHelper(
        mContext,
        DB_NAME,
        null,
        DB_VERSION
        ){
    override fun onCreate(db: SQLiteDatabase?) {
        TODO("Not yet implemented")
        //cree des tables
        val createTableUser= """
            CREATE TABLE users(
              $USERS_ID integer PRIMARY KEY,
              $NAME varchar(50),
              $EMAIL varchar(100),
              $PASSWORD varchar(20)
            )
        """.trimIndent()
        db?.execSQL(createTableUser)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")

        //supprimer les anciennes tables
        //Creation de nouvelles tables
        db?.execSQL("DROP TABLE IF EXISTS $USERS_TABLE_NAME")
        onCreate(db)


    }
//Declaration
    companion object {
        private val DB_NAME ="xget_db"
        private val DB_VERSION = 1
        private val USERS_TABLE_NAME ="users"
        private val USERS_ID ="id"
        private val NAME ="name"
        private val EMAIL ="email"
        private val PASSWORD ="password"
    }

}
