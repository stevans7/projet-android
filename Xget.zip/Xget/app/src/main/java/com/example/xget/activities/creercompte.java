package com.example.xget.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.xget.R;

public class creercompte extends AppCompatActivity {


    Button buttn;
    EditText edit;
    EditText editTpass1;
    EditText editTpass2;

    String usernames;
    String passwords;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_creercompte);



        buttn=(Button) findViewById(R.id.btncree);
        edit = findViewById(R.id.nomcree);
        editTpass1 = findViewById(R.id.passcree);
        editTpass2 = findViewById(R.id.confcreepass);

        buttn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                

                String username = edit.getText().toString();
                String password1 = editTpass1.getText().toString();
                String password2 = editTpass2.getText().toString();



                Intent intent= new Intent(creercompte.this, Menu.class);
                startActivity(intent);
            }
        });

    }
}